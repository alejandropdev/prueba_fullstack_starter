import { isAxiosError } from 'axios'

export class ApiError extends Error {
  readonly status: number

  constructor(status: number, message: string) {
    super(message)
    this.name = 'ApiError'
    this.status = status
  }
}

const MENSAJES_POR_ESTADO: Record<number, string> = {
  401: 'Tu sesión expiró. Ingresa de nuevo.',
  403: 'No tienes permiso para realizar esta acción.',
  404: 'El recurso no existe.',
  500: 'Error interno del servidor. Intenta de nuevo más tarde.',
}

/** Convierte cualquier error de axios en ApiError con un mensaje legible. */
export function toApiError(error: unknown): ApiError {
  if (error instanceof ApiError) return error
  if (!isAxiosError(error)) return new ApiError(0, error instanceof Error ? error.message : 'Ocurrió un error inesperado')
  if (!error.response) {
    return new ApiError(0, 'No se pudo conectar con el servidor. Verifica que la API esté en ejecución.')
  }

  const { status, data } = error.response
  // NestJS responde { statusCode, message, error }; message puede ser un arreglo (ValidationPipe).
  const message: unknown = (data as { message?: unknown } | undefined)?.message
  const text = Array.isArray(message) ? message.join('. ') : typeof message === 'string' ? message : undefined
  return new ApiError(status, text ?? MENSAJES_POR_ESTADO[status] ?? `Error ${status}`)
}

export function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : 'Ocurrió un error inesperado'
}
