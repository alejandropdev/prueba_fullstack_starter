import axios from 'axios'
import { clearSession, getToken } from '../features/auth/session'
import { toApiError } from './errors'

export const API_URL: string = import.meta.env.VITE_API_URL ?? 'http://localhost:3000'

export const http = axios.create({
  baseURL: API_URL,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
})

let onUnauthorized: (() => void) | null = null

/** Registra qué hacer cuando la API responde 401 (token vencido o inválido). */
export function setUnauthorizedHandler(handler: (() => void) | null): void {
  onUnauthorized = handler
}

http.interceptors.request.use((config) => {
  const token = getToken()
  if (token) config.headers.Authorization = `Bearer ${token}`
  // Permite cruzar en los logs del backend las peticiones de una misma acción del usuario.
  config.headers['X-Correlation-Id'] = crypto.randomUUID()
  return config
})

http.interceptors.response.use(
  (response) => response,
  (error) => {
    const apiError = toApiError(error)
    // El 401 del login significa "credenciales inválidas", no "sesión expirada".
    const esLogin = error?.config?.url?.includes('/auth/login')
    if (apiError.status === 401 && !esLogin) {
      clearSession()
      onUnauthorized?.()
    }
    return Promise.reject(apiError)
  },
)
