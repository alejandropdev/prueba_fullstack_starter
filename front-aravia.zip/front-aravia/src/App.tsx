import { useCallback, useEffect, useRef, useState } from 'react'
import { setUnauthorizedHandler } from './api/http'
import { AppLayout } from './components/layout/AppLayout'
import { Toast, type ToastMessage } from './components/ui/Toast'
import { logout } from './features/auth/api'
import { LoginPage } from './features/auth/LoginPage'
import { getStoredUser } from './features/auth/session'
import type { SessionUser } from './features/auth/types'
import { FacturaDetailPage } from './features/facturas/FacturaDetailPage'
import { FacturasPage } from './features/facturas/FacturasPage'

type View = { name: 'facturas' } | { name: 'factura'; id: string }

function App() {
  // Si hay sesión guardada (recarga de página) se restaura; un token vencido se detecta con el primer 401.
  const [user, setUser] = useState<SessionUser | null>(getStoredUser)
  const [view, setView] = useState<View>({ name: 'facturas' })
  const [toast, setToast] = useState<ToastMessage | null>(null)
  const toastId = useRef(0)

  const notify = useCallback((message: Omit<ToastMessage, 'id'>) => {
    toastId.current += 1
    setToast({ ...message, id: toastId.current })
  }, [])
  const dismissToast = useCallback(() => setToast(null), [])

  useEffect(() => {
    setUnauthorizedHandler(() => {
      setUser(null)
      notify({ kind: 'error', title: 'Sesión expirada', message: 'Ingresa de nuevo para continuar.' })
    })
    return () => setUnauthorizedHandler(null)
  }, [notify])

  if (!user) {
    return (
      <>
        <LoginPage
          onLogin={(loggedUser) => {
            setUser(loggedUser)
            setView({ name: 'facturas' })
            setToast(null)
          }}
        />
        {toast && <Toast toast={toast} onDismiss={dismissToast} />}
      </>
    )
  }

  return (
    <>
      <AppLayout
        user={user}
        section="facturas"
        onNavigate={() => setView({ name: 'facturas' })}
        onLogout={() => {
          logout()
          setUser(null)
          setToast(null)
        }}
      >
        {view.name === 'facturas' && <FacturasPage onOpen={(id) => setView({ name: 'factura', id })} />}
        {view.name === 'factura' && (
          <FacturaDetailPage key={view.id} facturaId={view.id} onBack={() => setView({ name: 'facturas' })} />
        )}
      </AppLayout>
      {toast && <Toast toast={toast} onDismiss={dismissToast} />}
    </>
  )
}

export default App
