import type { ReactNode } from 'react'
import type { SessionUser } from '../../features/auth/types'
import { getMyTenant } from '../../features/tenants/api'
import { useAsync } from '../../lib/useAsync'
import { Icon, type IconName } from '../ui/Icon'

// 'notas' se agrega cuando existan los endpoints de notas de crédito en el backend.
export type Section = 'facturas'

const NAV: { section: Section; label: string; icon: IconName }[] = [{ section: 'facturas', label: 'Facturas', icon: 'file' }]

const initials = (text: string) =>
  text
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word[0].toUpperCase())
    .join('')

interface AppLayoutProps {
  user: SessionUser
  section: Section
  onNavigate: (section: Section) => void
  onLogout: () => void
  children: ReactNode
}

export function AppLayout({ user, section, onNavigate, onLogout, children }: AppLayoutProps) {
  const { data: tenant } = useAsync(getMyTenant)

  const navButton = (item: (typeof NAV)[number], extra = '') => (
    <button
      key={item.section}
      type="button"
      onClick={() => onNavigate(item.section)}
      aria-current={section === item.section ? 'page' : undefined}
      className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition ${section === item.section ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'} ${extra}`}
    >
      <Icon name={item.icon} /> {item.label}
    </button>
  )

  return (
    <div className="min-h-screen bg-slate-50 md:flex">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-200 bg-white p-4 md:flex">
        <div className="flex items-center gap-2.5 px-2 py-1">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-600 font-bold text-white">A</span>
          <div className="leading-tight">
            <p className="font-semibold text-slate-900">Aravia</p>
            <p className="text-xs text-slate-500">Gestión financiera</p>
          </div>
        </div>

        <div className="mt-6 flex items-center gap-3 rounded-lg bg-slate-50 p-3 ring-1 ring-slate-200">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-slate-200 text-xs font-semibold text-slate-700">
            {tenant ? initials(tenant.name) : '··'}
          </span>
          <div className="min-w-0">
            <p className="text-xs text-slate-500">Empresa</p>
            <p className="truncate text-sm font-medium text-slate-900">{tenant?.name ?? 'Cargando…'}</p>
          </div>
        </div>

        <nav className="mt-6 flex flex-col gap-1" aria-label="Principal">
          {NAV.map((item) => navButton(item))}
        </nav>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-4 border-b border-slate-200 bg-white px-4 py-3 sm:px-6">
          <div className="min-w-0 md:hidden">
            <p className="font-semibold text-slate-900">Aravia</p>
            <p className="truncate text-xs text-slate-500">{tenant?.name}</p>
          </div>
          <div className="ml-auto flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-indigo-100 text-sm font-semibold text-indigo-700">
              {initials(user.fullName)}
            </span>
            <div className="hidden leading-tight sm:block">
              <p className="text-sm font-medium text-slate-900">{user.fullName}</p>
              <p className="text-xs text-slate-500">{user.email}</p>
            </div>
            <button
              type="button"
              onClick={onLogout}
              className="ml-2 flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            >
              <Icon name="logout" /> <span className="hidden sm:inline">Cerrar sesión</span>
            </button>
          </div>
        </header>

        <nav className="flex gap-1 overflow-x-auto border-b border-slate-200 bg-white px-4 py-2 md:hidden" aria-label="Principal">
          {NAV.map((item) => navButton(item, 'shrink-0'))}
        </nav>

        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6 lg:py-8">{children}</main>
      </div>
    </div>
  )
}
