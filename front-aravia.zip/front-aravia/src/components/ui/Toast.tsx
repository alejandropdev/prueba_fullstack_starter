import { useEffect } from 'react'
import { Icon } from './Icon'

export interface ToastMessage {
  id: number
  kind: 'success' | 'error'
  title: string
  message: string
}

export function Toast({ toast, onDismiss }: { toast: ToastMessage; onDismiss: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onDismiss, 4000)
    return () => clearTimeout(timer)
  }, [toast.id, onDismiss])

  const success = toast.kind === 'success'
  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed top-4 right-4 z-50 flex w-[calc(100%-2rem)] max-w-sm items-start gap-3 rounded-xl bg-white p-4 shadow-lg ring-1 ring-slate-200"
    >
      <span
        className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${success ? 'bg-emerald-100 text-emerald-600' : 'bg-red-100 text-red-600'}`}
      >
        <Icon name={success ? 'check' : 'alert'} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-slate-900">{toast.title}</p>
        <p className="mt-0.5 text-sm text-slate-500">{toast.message}</p>
      </div>
      <button type="button" onClick={onDismiss} aria-label="Cerrar aviso" className="text-slate-400 hover:text-slate-600">
        <Icon name="x" />
      </button>
    </div>
  )
}
