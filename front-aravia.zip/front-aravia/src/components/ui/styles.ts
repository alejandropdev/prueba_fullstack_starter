export const INPUT_CLASS =
  'block w-full rounded-lg border-0 px-3 py-2 text-sm text-slate-900 ring-1 ring-slate-300 ring-inset placeholder:text-slate-400 focus:ring-2 focus:ring-indigo-600 disabled:bg-slate-50 aria-[invalid=true]:ring-red-400'

export const CARD_CLASS = 'rounded-xl bg-white shadow-sm ring-1 ring-slate-200'
