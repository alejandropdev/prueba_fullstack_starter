import type { FacturaEstado } from '../../features/facturas/types'
import type { NotaCreditoEstado } from '../../features/notas-credito/types'

const FACTURA_STYLES: Record<FacturaEstado, string> = {
  emitida: 'bg-blue-50 text-blue-700 ring-blue-600/20',
  pagada: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
  anulada: 'bg-slate-100 text-slate-600 ring-slate-500/20',
}

const NOTA_STYLES: Record<NotaCreditoEstado, string> = {
  emitida: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
  anulada: 'bg-red-50 text-red-700 ring-red-600/20 line-through',
}

const BASE = 'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ring-1 ring-inset'

export function FacturaBadge({ estado }: { estado: FacturaEstado }) {
  return <span className={`${BASE} ${FACTURA_STYLES[estado]}`}>{estado}</span>
}

export function NotaBadge({ estado }: { estado: NotaCreditoEstado }) {
  return <span className={`${BASE} ${NOTA_STYLES[estado]}`}>{estado}</span>
}
