import { useEffect, useId, type ReactNode } from 'react'
import { Icon, type IconName } from './Icon'

interface ModalProps {
  title: string
  description?: string
  icon?: IconName
  tone?: 'default' | 'danger'
  /** Mientras es true no se puede cerrar (evita cancelar una operación en curso). */
  busy?: boolean
  onClose: () => void
  children: ReactNode
}

export function Modal({ title, description, icon, tone = 'default', busy = false, onClose, children }: ModalProps) {
  const titleId = useId()

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !busy) onClose()
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [busy, onClose])

  return (
    <div
      className="fixed inset-0 z-40 flex items-end justify-center bg-slate-900/50 p-4 sm:items-center"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget && !busy) onClose()
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className="relative max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-6 shadow-xl"
      >
        <button
          type="button"
          onClick={onClose}
          disabled={busy}
          aria-label="Cerrar"
          className="absolute top-4 right-4 rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 disabled:opacity-50"
        >
          <Icon name="x" className="h-5 w-5" />
        </button>
        {icon && (
          <div
            className={`mb-4 flex h-11 w-11 items-center justify-center rounded-full ${tone === 'danger' ? 'bg-red-100 text-red-600' : 'bg-indigo-100 text-indigo-600'}`}
          >
            <Icon name={icon} className="h-5 w-5" />
          </div>
        )}
        <h2 id={titleId} className="text-lg font-semibold text-slate-900">
          {title}
        </h2>
        {description && <p className="mt-1 text-sm text-slate-500">{description}</p>}
        <div className="mt-5">{children}</div>
      </div>
    </div>
  )
}
