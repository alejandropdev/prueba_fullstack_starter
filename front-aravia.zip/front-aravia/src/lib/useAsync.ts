import { useCallback, useEffect, useState } from 'react'

interface AsyncState<T> {
  data?: T
  error?: Error
  loading: boolean
}

/**
 * Ejecuta `loader` al montar y cada vez que cambia o se llama `reload`.
 * `loader` debe ser estable (useCallback o una función de módulo).
 */
export function useAsync<T>(loader: () => Promise<T>) {
  const [state, setState] = useState<AsyncState<T>>({ loading: true })
  const [version, setVersion] = useState(0)

  useEffect(() => {
    let active = true
    loader().then(
      (data) => active && setState({ data, loading: false }),
      (error: Error) => active && setState({ error, loading: false }),
    )
    return () => {
      active = false
    }
  }, [loader, version])

  const reload = useCallback(() => setVersion((v) => v + 1), [])

  return { ...state, reload }
}
