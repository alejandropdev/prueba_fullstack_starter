const dateFormat = new Intl.DateTimeFormat('es-CO', { day: '2-digit', month: 'short', year: 'numeric' })
const dateTimeFormat = new Intl.DateTimeFormat('es-CO', {
  day: '2-digit',
  month: 'short',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
})

/** "2025-08-20" → "20 ago 2025". Las fechas sin hora se leen en hora local para no correrse un día. */
export function formatDate(value: string): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value)
  const date = match ? new Date(+match[1], +match[2] - 1, +match[3]) : new Date(value)
  return dateFormat.format(date)
}

export function formatDateTime(value: string): string {
  return dateTimeFormat.format(new Date(value))
}
