// Todo el dinero se maneja como string y se opera en centavos con BigInt.
// Nunca usar Number(), parseFloat() ni aritmética de JS con decimales.

const MONEY_PATTERN = /^(-)?(\d+)(?:\.(\d{1,2}))?$/
const MONEY_INPUT_PATTERN = /^\d{1,12}(\.\d{1,2})?$/

/** "1500.25" → 150025n. Lanza error si el formato no es un monto válido (no redondea). */
export function toCents(value: string): bigint {
  const match = MONEY_PATTERN.exec(value.trim())
  if (!match) throw new Error(`Monto inválido: "${value}"`)
  const [, sign, whole, fraction = ''] = match
  const cents = BigInt(whole) * 100n + BigInt(fraction.padEnd(2, '0'))
  return sign ? -cents : cents
}

/** 150025n → "1500.25" */
export function fromCents(cents: bigint): string {
  const sign = cents < 0n ? '-' : ''
  const absolute = cents < 0n ? -cents : cents
  return `${sign}${absolute / 100n}.${(absolute % 100n).toString().padStart(2, '0')}`
}

export function compareMoney(a: string, b: string): -1 | 0 | 1 {
  const x = toCents(a)
  const y = toCents(b)
  return x < y ? -1 : x > y ? 1 : 0
}

export function addMoney(a: string, b: string): string {
  return fromCents(toCents(a) + toCents(b))
}

export function subtractMoney(a: string, b: string): string {
  return fromCents(toCents(a) - toCents(b))
}

export function sumMoney(values: string[]): string {
  return fromCents(values.reduce((sum, value) => sum + toCents(value), 0n))
}

/** Porcentaje entero (0-100) de `part` sobre `total`, sin pasar por number. */
export function percentOf(part: string, total: string): number {
  const totalCents = toCents(total)
  if (totalCents <= 0n) return 0
  const pct = (toCents(part) * 100n) / totalCents
  return Number(pct < 0n ? 0n : pct > 100n ? 100n : pct)
}

/** "2350750.50", "COP" → "$ 2.350.750,50" */
export function formatMoney(value: string, moneda: string): string {
  const normalized = fromCents(toCents(value))
  const negative = normalized.startsWith('-')
  const [whole, decimals] = normalized.replace('-', '').split('.')
  const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, '.')
  const symbol = moneda === 'COP' ? '$' : moneda
  return `${negative ? '-' : ''}${symbol} ${grouped},${decimals}`
}

/** Acepta coma o punto como separador decimal y lo normaliza a punto. */
export function normalizeMoneyInput(value: string): string {
  return value.trim().replace(',', '.')
}

/** Monto positivo, máximo 12 enteros y 2 decimales. */
export function isValidMoneyInput(value: string): boolean {
  const normalized = normalizeMoneyInput(value)
  return MONEY_INPUT_PATTERN.test(normalized) && toCents(normalized) > 0n
}
