import { http } from '../../api/http'
import type { Factura, FacturaEstado } from './types'

/** GET /facturas?estado= — el backend ya filtra por el tenant del token. */
export async function listFacturas(estado?: FacturaEstado): Promise<Factura[]> {
  const { data } = await http.get<Factura[]>('/facturas', { params: estado ? { estado } : undefined })
  return data
}

/** GET /facturas/:id — 404 si no existe o es de otro tenant. */
export async function getFactura(id: string): Promise<Factura> {
  const { data } = await http.get<Factura>(`/facturas/${encodeURIComponent(id)}`)
  return data
}
