import { useCallback } from 'react'
import { errorMessage } from '../../api/errors'
import { FacturaBadge } from '../../components/ui/Badge'
import { ErrorState, LoadingState } from '../../components/ui/Feedback'
import { Icon } from '../../components/ui/Icon'
import { PageHeader } from '../../components/ui/PageHeader'
import { CARD_CLASS } from '../../components/ui/styles'
import { formatDate, formatDateTime } from '../../lib/dates'
import { formatMoney, percentOf, subtractMoney } from '../../lib/money'
import { useAsync } from '../../lib/useAsync'
import { getFactura } from './api'

export function FacturaDetailPage({ facturaId, onBack }: { facturaId: string; onBack: () => void }) {
  const loader = useCallback(() => getFactura(facturaId), [facturaId])
  const { data: factura, loading, error } = useAsync(loader)

  const backButton = (
    <button type="button" onClick={onBack} className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-600 hover:text-slate-900">
      <Icon name="arrow-left" /> Volver a facturas
    </button>
  )

  if (loading) return <LoadingState label="Cargando factura…" />
  if (error || !factura) {
    return (
      <>
        {backButton}
        <ErrorState message={errorMessage(error)} />
      </>
    )
  }

  const pct = percentOf(factura.saldoPendiente, factura.montoTotal)
  const detalles: [string, string][] = [
    ['Fecha de emisión', formatDate(factura.fechaEmision)],
    ['Moneda', factura.moneda],
    ['Monto cobrado o acreditado', formatMoney(subtractMoney(factura.montoTotal, factura.saldoPendiente), factura.moneda)],
    ['Creada', formatDateTime(factura.createdAt)],
    ['Última actualización', formatDateTime(factura.updatedAt)],
  ]

  return (
    <>
      {backButton}
      <PageHeader
        title={
          <span className="flex flex-wrap items-center gap-3">
            {factura.numeroFactura} <FacturaBadge estado={factura.estado} />
          </span>
        }
        description={factura.concepto}
      />

      <div className={`${CARD_CLASS} p-5 sm:p-6`}>
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold tracking-wide text-slate-500 uppercase">Saldo pendiente</p>
            <p className="mt-1 text-3xl font-semibold text-slate-900 tabular-nums">
              {formatMoney(factura.saldoPendiente, factura.moneda)}
            </p>
            <p className="mt-1 text-sm text-slate-500 tabular-nums">de {formatMoney(factura.montoTotal, factura.moneda)} total</p>
          </div>
          <p className="text-sm text-slate-600">
            <span className="text-lg font-semibold text-slate-900">{pct}%</span> por cobrar
          </p>
        </div>
        <div
          className="mt-4 h-2 overflow-hidden rounded-full bg-slate-100"
          role="progressbar"
          aria-valuenow={pct}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Porcentaje del total por cobrar"
        >
          <div className="h-full rounded-full bg-indigo-600 transition-all" style={{ width: `${pct}%` }} />
        </div>
        <dl className="mt-5 grid gap-4 border-t border-slate-100 pt-5 text-sm sm:grid-cols-3">
          {detalles.map(([label, value]) => (
            <div key={label}>
              <dt className="text-slate-500">{label}</dt>
              <dd className="mt-0.5 font-medium text-slate-900 tabular-nums">{value}</dd>
            </div>
          ))}
          <div className="min-w-0">
            <dt className="text-slate-500">Identificador</dt>
            <dd className="mt-0.5 truncate font-mono text-xs text-slate-600" title={factura.id}>
              {factura.id}
            </dd>
          </div>
        </dl>
      </div>
    </>
  )
}
