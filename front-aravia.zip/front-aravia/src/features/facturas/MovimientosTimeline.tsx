import { EmptyState } from '../../components/ui/Feedback'
import { Icon, type IconName } from '../../components/ui/Icon'
import { formatDateTime } from '../../lib/dates'
import { formatMoney } from '../../lib/money'
import type { Movimiento, MovimientoTipo } from './types'

const TIPOS: Record<MovimientoTipo, { label: string; sign: '+' | '-' | ''; icon: IconName; color: string }> = {
  emision: { label: 'Saldo inicial', sign: '', icon: 'file', color: 'bg-blue-100 text-blue-600' },
  pago: { label: 'Pago', sign: '-', icon: 'arrow-down-left', color: 'bg-emerald-100 text-emerald-600' },
  nota_credito: { label: 'Nota de crédito aplicada', sign: '-', icon: 'arrow-down-left', color: 'bg-emerald-100 text-emerald-600' },
  anulacion_nota_credito: { label: 'Nota de crédito anulada', sign: '+', icon: 'arrow-up-right', color: 'bg-red-100 text-red-600' },
  ajuste: { label: 'Ajuste', sign: '', icon: 'alert', color: 'bg-amber-100 text-amber-600' },
}

export function MovimientosTimeline({ movimientos, moneda }: { movimientos: Movimiento[]; moneda: string }) {
  if (!movimientos.length) return <EmptyState>Esta factura no tiene movimientos.</EmptyState>

  return (
    <ol className="space-y-5">
      {movimientos.map((movimiento) => {
        const tipo = TIPOS[movimiento.tipo]
        const trazabilidad: [string, string | null][] = [
          ['Usuario', movimiento.createdBy],
          ['IP', movimiento.ipAddress],
          ['User agent', movimiento.userAgent],
          ['Request ID', movimiento.requestId],
          ['Correlation ID', movimiento.correlationId],
        ]
        return (
          <li key={movimiento.id} className="flex gap-3">
            <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${tipo.color}`}>
              <Icon name={tipo.icon} />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                <p className="font-medium text-slate-900">{tipo.label}</p>
                <p
                  className={`font-semibold tabular-nums ${tipo.sign === '-' ? 'text-emerald-700' : tipo.sign === '+' ? 'text-red-600' : 'text-slate-900'}`}
                >
                  {tipo.sign && `${tipo.sign} `}
                  {formatMoney(movimiento.monto, moneda)}
                </p>
              </div>
              <p className="text-xs text-slate-500">{formatDateTime(movimiento.createdAt)}</p>
              {movimiento.descripcion && <p className="mt-1 text-sm text-slate-600">{movimiento.descripcion}</p>}
              <p className="mt-1 text-xs text-slate-500 tabular-nums">
                Saldo {formatMoney(movimiento.saldoAnterior, moneda)} → {formatMoney(movimiento.saldoPosterior, moneda)}
              </p>
              <details className="mt-2 text-xs">
                <summary className="cursor-pointer text-indigo-600 select-none hover:text-indigo-500">Trazabilidad</summary>
                <dl className="mt-2 grid gap-x-4 gap-y-1 rounded-lg bg-slate-50 p-3 sm:grid-cols-[auto_1fr]">
                  {trazabilidad.map(([label, value]) => (
                    <div key={label} className="contents">
                      <dt className="text-slate-500">{label}</dt>
                      <dd className="font-mono break-all text-slate-700">{value ?? '—'}</dd>
                    </div>
                  ))}
                </dl>
              </details>
            </div>
          </li>
        )
      })}
    </ol>
  )
}
