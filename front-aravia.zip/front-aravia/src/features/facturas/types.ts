export type FacturaEstado = 'emitida' | 'pagada' | 'anulada'

export interface Factura {
  id: string
  tenantId: string
  numeroFactura: string
  montoTotal: string
  saldoPendiente: string
  estado: FacturaEstado
  moneda: string
  concepto: string | null
  fechaEmision: string
  createdAt: string
  updatedAt: string
}

export type MovimientoTipo = 'emision' | 'pago' | 'nota_credito' | 'anulacion_nota_credito' | 'ajuste'

export interface Movimiento {
  id: string
  facturaId: string
  notaCreditoId: string | null
  tipo: MovimientoTipo
  monto: string
  saldoAnterior: string
  saldoPosterior: string
  descripcion: string | null
  createdBy: string
  createdAt: string
  ipAddress: string | null
  userAgent: string | null
  requestId: string | null
  correlationId: string | null
}
