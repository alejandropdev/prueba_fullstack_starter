import { FacturaBadge } from '../../components/ui/Badge'
import { EmptyState } from '../../components/ui/Feedback'
import { Icon } from '../../components/ui/Icon'
import { formatDate } from '../../lib/dates'
import { formatMoney } from '../../lib/money'
import type { Factura } from './types'

export function FacturasTable({ facturas, onOpen }: { facturas: Factura[]; onOpen: (id: string) => void }) {
  if (!facturas.length) return <EmptyState>No se encontraron facturas.</EmptyState>

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-slate-200 text-sm">
        <thead className="bg-slate-50 text-left text-xs font-semibold tracking-wide text-slate-500 uppercase">
          <tr>
            <th className="px-4 py-3">Factura</th>
            <th className="px-4 py-3">Concepto</th>
            <th className="px-4 py-3">Emisión</th>
            <th className="px-4 py-3 text-right">Total</th>
            <th className="px-4 py-3 text-right">Saldo pendiente</th>
            <th className="px-4 py-3">Estado</th>
            <th className="px-4 py-3">
              <span className="sr-only">Acciones</span>
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {facturas.map((factura) => (
            <tr key={factura.id} className="hover:bg-slate-50">
              <td className="px-4 py-3 font-medium whitespace-nowrap text-slate-900">{factura.numeroFactura}</td>
              <td className="max-w-xs truncate px-4 py-3 text-slate-600">{factura.concepto ?? '—'}</td>
              <td className="px-4 py-3 whitespace-nowrap text-slate-600">{formatDate(factura.fechaEmision)}</td>
              <td className="px-4 py-3 text-right whitespace-nowrap text-slate-600 tabular-nums">
                {formatMoney(factura.montoTotal, factura.moneda)}
              </td>
              <td className="px-4 py-3 text-right font-semibold whitespace-nowrap text-slate-900 tabular-nums">
                {formatMoney(factura.saldoPendiente, factura.moneda)}
              </td>
              <td className="px-4 py-3">
                <FacturaBadge estado={factura.estado} />
              </td>
              <td className="px-4 py-3 text-right">
                <button
                  type="button"
                  onClick={() => onOpen(factura.id)}
                  className="inline-flex items-center gap-1 text-sm font-medium whitespace-nowrap text-indigo-600 hover:text-indigo-500"
                >
                  Ver detalle <Icon name="arrow-right" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
