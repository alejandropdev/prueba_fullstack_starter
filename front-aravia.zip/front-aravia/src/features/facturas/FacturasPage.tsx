import { useCallback, useState } from 'react'
import { listFacturas } from './api'
import { errorMessage } from '../../api/errors'
import { ErrorState, LoadingState } from '../../components/ui/Feedback'
import { PageHeader } from '../../components/ui/PageHeader'
import { SearchInput } from '../../components/ui/SearchInput'
import { CARD_CLASS } from '../../components/ui/styles'
import { Tabs } from '../../components/ui/Tabs'
import { formatMoney, sumMoney } from '../../lib/money'
import { useAsync } from '../../lib/useAsync'
import { FacturasTable } from './FacturasTable'
import type { FacturaEstado } from './types'

type Filtro = 'todas' | FacturaEstado

export function FacturasPage({ onOpen }: { onOpen: (id: string) => void }) {
  // Se piden todas (sin ?estado) para calcular los contadores de cada pestaña.
  const loader = useCallback(() => listFacturas(), [])
  const { data: facturas, loading, error } = useAsync(loader)
  const [filtro, setFiltro] = useState<Filtro>('todas')
  const [query, setQuery] = useState('')

  if (loading) return <LoadingState label="Cargando facturas…" />
  if (error || !facturas) return <ErrorState message={errorMessage(error)} />

  const count = (estado: FacturaEstado) => facturas.filter((f) => f.estado === estado).length
  const term = query.trim().toLowerCase()
  const visibles = facturas.filter(
    (f) =>
      (filtro === 'todas' || f.estado === filtro) &&
      `${f.numeroFactura} ${f.concepto ?? ''}`.toLowerCase().includes(term),
  )
  const saldoTotal = sumMoney(facturas.filter((f) => f.moneda === 'COP').map((f) => f.saldoPendiente))

  const summary = [
    { label: 'Facturas emitidas', value: String(count('emitida')) },
    { label: 'Saldo pendiente total', value: formatMoney(saldoTotal, 'COP') },
    { label: 'Facturas pagadas', value: String(count('pagada')) },
  ]

  return (
    <>
      <PageHeader eyebrow="Gestión financiera" title="Facturas" description="Consulta las facturas de tu empresa." />

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        {summary.map((item) => (
          <div key={item.label} className={`${CARD_CLASS} p-5`}>
            <p className="text-sm text-slate-500">{item.label}</p>
            <p className="mt-1 text-2xl font-semibold text-slate-900 tabular-nums">{item.value}</p>
          </div>
        ))}
      </div>

      <div className={CARD_CLASS}>
        <div className="flex flex-col gap-3 border-b border-slate-200 p-4 sm:flex-row sm:items-center sm:justify-between">
          <Tabs
            value={filtro}
            onChange={setFiltro}
            options={[
              { value: 'todas', label: 'Todas', count: facturas.length },
              { value: 'emitida', label: 'Emitidas', count: count('emitida') },
              { value: 'pagada', label: 'Pagadas', count: count('pagada') },
              { value: 'anulada', label: 'Anuladas', count: count('anulada') },
            ]}
          />
          <SearchInput value={query} onChange={setQuery} placeholder="Buscar por número o concepto" />
        </div>
        <FacturasTable facturas={visibles} onOpen={onOpen} />
      </div>
    </>
  )
}
