import { useState, type FormEvent } from 'react'
import { login } from './api'
import { errorMessage } from '../../api/errors'
import { Button } from '../../components/ui/Button'
import { Field } from '../../components/ui/Field'
import { FormError, Spinner } from '../../components/ui/Feedback'
import { Icon } from '../../components/ui/Icon'
import { INPUT_CLASS } from '../../components/ui/styles'
import type { SessionUser } from './types'

const TEST_USERS = [
  { email: 'ana.gomez@elroble.test', tenant: 'El Roble' },
  { email: 'maria.lopez@textilesandinos.test', tenant: 'Textiles Andinos' },
  { email: 'juan.perez@solucionesnorte.test', tenant: 'Soluciones Norte' },
]

export function LoginPage({ onLogin }: { onLogin: (user: SessionUser) => void }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const submit = async (event: FormEvent) => {
    event.preventDefault()
    setBusy(true)
    setError(null)
    try {
      onLogin(await login(email, password))
    } catch (err) {
      setError(errorMessage(err))
      setBusy(false)
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex items-center justify-center gap-2.5">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600 font-bold text-white">A</span>
          <div className="leading-tight">
            <p className="font-semibold text-slate-900">Aravia</p>
            <p className="text-xs text-slate-500">Gestión financiera</p>
          </div>
        </div>

        <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200 sm:p-8">
          <h1 className="text-xl font-semibold text-slate-900">Bienvenido de nuevo</h1>
          <p className="mt-1 text-sm text-slate-500">Ingresa a tu cuenta para continuar.</p>

          <form onSubmit={submit} className="mt-6 space-y-4">
            <Field label="Correo electrónico" htmlFor="email">
              <input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={busy}
                className={INPUT_CLASS}
              />
            </Field>
            <Field label="Contraseña" htmlFor="password">
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={busy}
                className={INPUT_CLASS}
              />
            </Field>
            <FormError message={error} />
            <Button type="submit" disabled={busy} className="w-full">
              {busy ? <Spinner /> : null}
              Ingresar
              {!busy && <Icon name="arrow-right" />}
            </Button>
          </form>
        </div>

        <div className="mt-6 rounded-xl bg-white p-4 text-xs text-slate-500 ring-1 ring-slate-200">
          <p className="font-medium text-slate-700">Usuarios de prueba · contraseña password123</p>
          <ul className="mt-2 space-y-1">
            {TEST_USERS.map((user) => (
              <li key={user.email}>
                <button
                  type="button"
                  onClick={() => setEmail(user.email)}
                  className="text-indigo-600 hover:underline"
                >
                  {user.email}
                </button>{' '}
                · {user.tenant}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </main>
  )
}
