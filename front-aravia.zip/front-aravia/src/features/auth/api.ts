import { http } from '../../api/http'
import { clearSession, saveSession } from './session'
import type { SessionUser } from './types'

interface LoginResponse {
  accessToken: string
  user: SessionUser
}

/** POST /auth/login */
export async function login(email: string, password: string): Promise<SessionUser> {
  const { data } = await http.post<LoginResponse>('/auth/login', { email: email.trim(), password })
  saveSession(data.accessToken, data.user)
  return data.user
}

/** El backend usa JWT sin estado: cerrar sesión es descartar el token. */
export function logout(): void {
  clearSession()
}
