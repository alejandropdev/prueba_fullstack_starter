import type { SessionUser } from './types'

// sessionStorage: la sesión sobrevive a recargar la página pero se borra al cerrar la pestaña.
const TOKEN_KEY = 'aravia.token'
const USER_KEY = 'aravia.user'

function read(key: string): string | null {
  try {
    return sessionStorage.getItem(key)
  } catch {
    return null
  }
}

export function getToken(): string | null {
  return read(TOKEN_KEY)
}

export function getStoredUser(): SessionUser | null {
  const raw = read(USER_KEY)
  if (!raw || !getToken()) return null
  try {
    return JSON.parse(raw) as SessionUser
  } catch {
    return null
  }
}

export function saveSession(token: string, user: SessionUser): void {
  try {
    sessionStorage.setItem(TOKEN_KEY, token)
    sessionStorage.setItem(USER_KEY, JSON.stringify(user))
  } catch {
    // Sin storage disponible la sesión simplemente no persiste al recargar.
  }
}

export function clearSession(): void {
  try {
    sessionStorage.removeItem(TOKEN_KEY)
    sessionStorage.removeItem(USER_KEY)
  } catch {
    // nada que limpiar
  }
}
