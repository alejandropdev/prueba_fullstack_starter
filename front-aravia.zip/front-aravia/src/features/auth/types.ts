export interface SessionUser {
  id: string
  email: string
  fullName: string
  tenantId: string
}
