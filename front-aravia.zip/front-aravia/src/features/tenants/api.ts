import { http } from '../../api/http'
import type { Tenant } from './types'

/** GET /tenants/me — el tenant sale del JWT, nunca se envía desde el front. */
export async function getMyTenant(): Promise<Tenant> {
  const { data } = await http.get<Tenant>('/tenants/me')
  return data
}
