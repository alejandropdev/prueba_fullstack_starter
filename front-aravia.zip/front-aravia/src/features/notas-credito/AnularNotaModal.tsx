import { useState, type FormEvent } from 'react'
import { anularNota } from './api'
import { ApiError, errorMessage } from '../../api/errors'
import { Button } from '../../components/ui/Button'
import { Field } from '../../components/ui/Field'
import { FormError, Spinner } from '../../components/ui/Feedback'
import { Modal } from '../../components/ui/Modal'
import { INPUT_CLASS } from '../../components/ui/styles'
import { formatDateTime } from '../../lib/dates'
import { formatMoney } from '../../lib/money'
import type { NotaCredito } from './types'

interface AnularNotaModalProps {
  nota: NotaCredito
  moneda: string
  onClose: () => void
  onAnulada: (nota: NotaCredito) => void
  onStale: () => void
}

export function AnularNotaModal({ nota, moneda, onClose, onAnulada, onStale }: AnularNotaModalProps) {
  const [motivo, setMotivo] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const submit = async (event: FormEvent) => {
    event.preventDefault()
    if (!motivo.trim()) return
    setBusy(true)
    setError(null)
    try {
      onAnulada(await anularNota(nota.id, motivo))
    } catch (err) {
      setError(errorMessage(err))
      if (err instanceof ApiError && (err.status === 404 || err.status === 409)) onStale()
      setBusy(false)
    }
  }

  return (
    <Modal
      title="Anular nota de crédito"
      description="Esta acción es permanente y quedará registrada en el historial."
      icon="ban"
      tone="danger"
      busy={busy}
      onClose={onClose}
    >
      <form onSubmit={submit} className="space-y-4">
        <dl className="grid grid-cols-3 gap-2 rounded-lg bg-slate-50 px-4 py-3 text-sm">
          <div>
            <dt className="text-xs text-slate-500">Nota</dt>
            <dd className="font-medium text-slate-900">{nota.numeroNota}</dd>
          </div>
          <div>
            <dt className="text-xs text-slate-500">Monto</dt>
            <dd className="font-medium text-slate-900 tabular-nums">{formatMoney(nota.monto, moneda)}</dd>
          </div>
          <div>
            <dt className="text-xs text-slate-500">Fecha</dt>
            <dd className="font-medium text-slate-900">{formatDateTime(nota.createdAt)}</dd>
          </div>
        </dl>

        <div className="rounded-lg bg-red-50 p-3 text-sm text-red-800 ring-1 ring-red-200">
          El monto de <strong className="tabular-nums">{formatMoney(nota.monto, moneda)}</strong> volverá al saldo de la factura y la
          nota quedará anulada de forma permanente.
        </div>

        <Field label="Motivo de anulación" htmlFor="motivo-anulacion" hint={`${motivo.length}/500`}>
          <textarea
            id="motivo-anulacion"
            autoFocus
            required
            rows={3}
            maxLength={500}
            value={motivo}
            onChange={(e) => setMotivo(e.target.value)}
            placeholder="Indica el motivo de la anulación…"
            disabled={busy}
            className={INPUT_CLASS}
          />
        </Field>

        <FormError message={error} />

        <div className="flex flex-col-reverse gap-2 pt-2 sm:flex-row sm:justify-end">
          <Button variant="secondary" disabled={busy} onClick={onClose}>
            Cancelar
          </Button>
          <Button type="submit" variant="danger" disabled={!motivo.trim() || busy}>
            {busy && <Spinner />}
            Anular nota
          </Button>
        </div>
      </form>
    </Modal>
  )
}
