import { useState, type FormEvent } from 'react'
import { crearNota } from './api'
import { ApiError, errorMessage } from '../../api/errors'
import { Button } from '../../components/ui/Button'
import { Field } from '../../components/ui/Field'
import { FormError, Spinner } from '../../components/ui/Feedback'
import { Modal } from '../../components/ui/Modal'
import { INPUT_CLASS } from '../../components/ui/styles'
import { formatMoney, isValidMoneyInput, normalizeMoneyInput, subtractMoney, toCents } from '../../lib/money'
import type { Factura } from '../facturas/types'
import { MOTIVOS_NOTA, type CrearNotaResult } from './types'

interface CrearNotaModalProps {
  factura: Factura
  onClose: () => void
  onCreated: (nota: CrearNotaResult) => void
  /** El servidor indicó que los datos cambiaron (otro usuario modificó la factura). */
  onStale: () => void
}

const ERRORES: Record<number, string> = {
  404: 'La factura ya no existe.',
  422: 'El monto supera el saldo pendiente actual. Es posible que otro usuario haya modificado la factura; el saldo se actualizó.',
}

export function CrearNotaModal({ factura, onClose, onCreated, onStale }: CrearNotaModalProps) {
  const [monto, setMonto] = useState('')
  const [motivo, setMotivo] = useState('')
  const [descripcion, setDescripcion] = useState('')
  const [confirmando, setConfirmando] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  // Una key por intención de crear: se reutiliza en reintentos y solo cambia si cambia el monto.
  const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID())

  const moneda = factura.moneda
  const formatoValido = isValidMoneyInput(monto)
  const montoNormalizado = formatoValido ? normalizeMoneyInput(monto) : null
  const excede = montoNormalizado !== null && toCents(montoNormalizado) > toCents(factura.saldoPendiente)
  const saldoResultante = montoNormalizado && !excede ? subtractMoney(factura.saldoPendiente, montoNormalizado) : null
  const puedeContinuar = saldoResultante !== null && motivo !== ''

  const errorMonto =
    monto.trim() === ''
      ? null
      : !formatoValido
        ? 'Ingresa un monto mayor a 0 con máximo 2 decimales.'
        : excede
          ? 'El monto supera el saldo pendiente.'
          : null

  const cambiarMonto = (value: string) => {
    setMonto(value)
    setIdempotencyKey(crypto.randomUUID())
  }

  const submit = async (event: FormEvent) => {
    event.preventDefault()
    if (!puedeContinuar || !montoNormalizado) return
    if (!confirmando) {
      setConfirmando(true)
      return
    }
    setBusy(true)
    setError(null)
    try {
      const nota = await crearNota(
        factura.id,
        { monto: montoNormalizado, motivo, descripcion: descripcion.trim() || undefined },
        idempotencyKey,
      )
      onCreated(nota)
    } catch (err) {
      const status = err instanceof ApiError ? err.status : 0
      setError(ERRORES[status] ?? errorMessage(err))
      if (status === 409 || status === 422) onStale()
      setConfirmando(false)
      setBusy(false)
    }
  }

  return (
    <Modal
      title="Crear nota de crédito"
      description="Se aplicará una reducción al saldo pendiente de la factura."
      icon="arrow-down-left"
      busy={busy}
      onClose={onClose}
    >
      <form onSubmit={submit} className="space-y-4">
        <div className="flex items-center justify-between rounded-lg bg-slate-50 px-4 py-3 text-sm">
          <span className="font-medium text-slate-900">{factura.numeroFactura}</span>
          <span className="text-slate-500">
            Saldo pendiente{' '}
            <strong className="text-slate-900 tabular-nums">{formatMoney(factura.saldoPendiente, moneda)}</strong>
          </span>
        </div>

        {confirmando && saldoResultante && montoNormalizado ? (
          <div className="rounded-lg bg-amber-50 p-4 text-sm text-amber-900 ring-1 ring-amber-200">
            <p className="font-semibold">Confirma la operación</p>
            <p className="mt-1">
              Se creará una nota por <strong className="tabular-nums">{formatMoney(montoNormalizado, moneda)}</strong> ({motivo}). El saldo
              pasará de <strong className="tabular-nums">{formatMoney(factura.saldoPendiente, moneda)}</strong> a{' '}
              <strong className="tabular-nums">{formatMoney(saldoResultante, moneda)}</strong>.
            </p>
            <p className="mt-2 text-xs">La nota no se podrá editar; solo anular.</p>
          </div>
        ) : (
          <>
            <Field
              label="Monto de la nota"
              htmlFor="monto"
              error={errorMonto}
              hint={
                <button
                  type="button"
                  onClick={() => cambiarMonto(factura.saldoPendiente)}
                  className="font-medium text-indigo-600 hover:text-indigo-500"
                >
                  Usar saldo total ({formatMoney(factura.saldoPendiente, moneda)})
                </button>
              }
            >
              <div className="relative">
                <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-sm text-slate-400">$</span>
                <input
                  id="monto"
                  autoFocus
                  inputMode="decimal"
                  autoComplete="off"
                  placeholder="0,00"
                  value={monto}
                  onChange={(e) => cambiarMonto(e.target.value)}
                  aria-invalid={errorMonto !== null}
                  className={`${INPUT_CLASS} pr-14 pl-7 tabular-nums`}
                />
                <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-xs text-slate-400">{moneda}</span>
              </div>
            </Field>

            <Field label="Motivo" htmlFor="motivo">
              <select id="motivo" required value={motivo} onChange={(e) => setMotivo(e.target.value)} className={INPUT_CLASS}>
                <option value="">Selecciona un motivo</option>
                {MOTIVOS_NOTA.map((m) => (
                  <option key={m}>{m}</option>
                ))}
              </select>
            </Field>

            <Field label="Descripción" htmlFor="descripcion" optional hint={`${descripcion.length}/500`}>
              <textarea
                id="descripcion"
                rows={3}
                maxLength={500}
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
                placeholder="Añade información adicional…"
                className={INPUT_CLASS}
              />
            </Field>

            <div className="flex items-center justify-between rounded-lg bg-indigo-50 px-4 py-3 text-sm">
              <span className="text-slate-600">Saldo resultante</span>
              <strong className="text-indigo-700 tabular-nums">
                {saldoResultante ? formatMoney(saldoResultante, moneda) : '—'}
              </strong>
            </div>
          </>
        )}

        <FormError message={error} />

        <div className="flex flex-col-reverse gap-2 pt-2 sm:flex-row sm:justify-end">
          <Button
            variant="secondary"
            disabled={busy}
            onClick={() => (confirmando ? setConfirmando(false) : onClose())}
          >
            {confirmando ? 'Volver' : 'Cancelar'}
          </Button>
          <Button type="submit" disabled={!puedeContinuar || busy}>
            {busy && <Spinner />}
            {confirmando ? 'Confirmar y crear' : 'Continuar'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}
