import { useCallback, useState } from 'react'
import { listFacturas } from '../facturas/api'
import { listNotas } from './api'
import { errorMessage } from '../../api/errors'
import { ErrorState, LoadingState } from '../../components/ui/Feedback'
import { PageHeader } from '../../components/ui/PageHeader'
import { SearchInput } from '../../components/ui/SearchInput'
import { CARD_CLASS } from '../../components/ui/styles'
import { Tabs } from '../../components/ui/Tabs'
import type { ToastMessage } from '../../components/ui/Toast'
import { useAsync } from '../../lib/useAsync'
import { AnularNotaModal } from './AnularNotaModal'
import { NotasCreditoTable } from './NotasCreditoTable'
import type { NotaCredito, NotaCreditoEstado } from './types'

type Filtro = 'todas' | NotaCreditoEstado

interface NotasCreditoPageProps {
  onOpenFactura: (facturaId: string) => void
  notify: (toast: Omit<ToastMessage, 'id'>) => void
}

export function NotasCreditoPage({ onOpenFactura, notify }: NotasCreditoPageProps) {
  const loader = useCallback(() => Promise.all([listNotas(), listFacturas()]), [])
  const { data, loading, error, reload } = useAsync(loader)
  const [filtro, setFiltro] = useState<Filtro>('todas')
  const [query, setQuery] = useState('')
  const [anulando, setAnulando] = useState<NotaCredito | null>(null)

  if (loading) return <LoadingState label="Cargando notas de crédito…" />
  if (error || !data) return <ErrorState message={errorMessage(error)} />

  const [notas, facturas] = data
  const facturasPorId = new Map(facturas.map((f) => [f.id, f]))
  const count = (estado: NotaCreditoEstado) => notas.filter((n) => n.estado === estado).length
  const term = query.trim().toLowerCase()
  const visibles = notas.filter(
    (n) =>
      (filtro === 'todas' || n.estado === filtro) &&
      `${n.numeroNota} ${facturasPorId.get(n.facturaId)?.numeroFactura ?? ''}`.toLowerCase().includes(term),
  )

  return (
    <>
      <PageHeader
        eyebrow="Control de ajustes"
        title="Notas de crédito"
        description="Historial de reducciones aplicadas a tus facturas. Para crear una nota, abre la factura correspondiente."
      />

      <div className={CARD_CLASS}>
        <div className="flex flex-col gap-3 border-b border-slate-200 p-4 sm:flex-row sm:items-center sm:justify-between">
          <Tabs
            value={filtro}
            onChange={setFiltro}
            options={[
              { value: 'todas', label: 'Todas', count: notas.length },
              { value: 'emitida', label: 'Emitidas', count: count('emitida') },
              { value: 'anulada', label: 'Anuladas', count: count('anulada') },
            ]}
          />
          <SearchInput value={query} onChange={setQuery} placeholder="Buscar por nota o factura" />
        </div>
        <NotasCreditoTable
          notas={visibles}
          moneda="COP"
          onAnular={setAnulando}
          factura={{
            numero: (id) => facturasPorId.get(id)?.numeroFactura ?? '—',
            onOpen: onOpenFactura,
          }}
        />
      </div>

      {anulando && (
        <AnularNotaModal
          nota={anulando}
          moneda={facturasPorId.get(anulando.facturaId)?.moneda ?? 'COP'}
          onClose={() => setAnulando(null)}
          onStale={reload}
          onAnulada={(nota) => {
            setAnulando(null)
            reload()
            notify({ kind: 'success', title: 'Nota anulada', message: `La nota ${nota.numeroNota} fue anulada.` })
          }}
        />
      )}
    </>
  )
}
