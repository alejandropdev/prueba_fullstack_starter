import { NotaBadge } from '../../components/ui/Badge'
import { Button } from '../../components/ui/Button'
import { EmptyState } from '../../components/ui/Feedback'
import { formatDateTime } from '../../lib/dates'
import { formatMoney } from '../../lib/money'
import type { NotaCredito } from './types'

interface NotasCreditoTableProps {
  notas: NotaCredito[]
  moneda: string
  onAnular: (nota: NotaCredito) => void
  /** Si se pasa, se muestra la columna de factura con enlace. */
  factura?: { numero: (facturaId: string) => string; onOpen: (facturaId: string) => void }
}

export function NotasCreditoTable({ notas, moneda, onAnular, factura }: NotasCreditoTableProps) {
  if (!notas.length) return <EmptyState>No hay notas de crédito.</EmptyState>

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-slate-200 text-sm">
        <thead className="bg-slate-50 text-left text-xs font-semibold tracking-wide text-slate-500 uppercase">
          <tr>
            <th className="px-4 py-3">Nota</th>
            {factura && <th className="px-4 py-3">Factura</th>}
            <th className="px-4 py-3">Fecha</th>
            <th className="px-4 py-3 text-right">Monto</th>
            <th className="px-4 py-3">Motivo</th>
            <th className="px-4 py-3">Estado</th>
            <th className="px-4 py-3">
              <span className="sr-only">Acciones</span>
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {notas.map((nota) => (
            <tr key={nota.id} className="hover:bg-slate-50">
              <td className="px-4 py-3 font-medium whitespace-nowrap text-slate-900">{nota.numeroNota}</td>
              {factura && (
                <td className="px-4 py-3 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => factura.onOpen(nota.facturaId)}
                    className="font-medium text-indigo-600 hover:text-indigo-500 hover:underline"
                  >
                    {factura.numero(nota.facturaId)}
                  </button>
                </td>
              )}
              <td className="px-4 py-3 whitespace-nowrap text-slate-600">{formatDateTime(nota.createdAt)}</td>
              <td className="px-4 py-3 text-right font-semibold whitespace-nowrap text-slate-900 tabular-nums">
                {formatMoney(nota.monto, moneda)}
              </td>
              <td className="px-4 py-3 text-slate-600">
                <p>{nota.motivo}</p>
                {nota.descripcion && <p className="max-w-xs truncate text-xs text-slate-400">{nota.descripcion}</p>}
              </td>
              <td className="px-4 py-3">
                <NotaBadge estado={nota.estado} />
              </td>
              <td className="px-4 py-3 text-right">
                {nota.estado === 'emitida' && (
                  <Button variant="outline-danger" className="px-2.5 py-1 text-xs" onClick={() => onAnular(nota)}>
                    Anular
                  </Button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
