export type NotaCreditoEstado = 'emitida' | 'anulada'

export interface NotaCredito {
  id: string
  facturaId: string
  numeroNota: string
  monto: string
  motivo: string
  descripcion: string | null
  estado: NotaCreditoEstado
  createdBy: string
  createdAt: string
  updatedAt: string
  ipAddress: string | null
  requestId: string | null
}

export interface CrearNotaInput {
  monto: string
  motivo: string
  descripcion?: string
}

export interface CrearNotaResult extends NotaCredito {
  saldoAnterior: string
  saldoPosterior: string
}

export const MOTIVOS_NOTA = ['Devolución', 'Descuento', 'Error de facturación', 'Otro'] as const
