// PENDIENTE: estos endpoints aún no existen en el backend. Siguen el contrato de
// docs/notas-credito/PROMPT_FRONTEND.md y no están montados en la UI todavía.
import { http } from '../../api/http'
import type { Movimiento } from '../facturas/types'
import type { CrearNotaInput, CrearNotaResult, NotaCredito } from './types'

export async function listNotas(): Promise<NotaCredito[]> {
  const { data } = await http.get<{ data: NotaCredito[] }>('/notas-credito')
  return data.data
}

export async function listNotasByFactura(facturaId: string): Promise<NotaCredito[]> {
  const { data } = await http.get<NotaCredito[]>(`/facturas/${encodeURIComponent(facturaId)}/notas-credito`)
  return data
}

export async function listMovimientos(facturaId: string): Promise<Movimiento[]> {
  const { data } = await http.get<Movimiento[]>(`/facturas/${encodeURIComponent(facturaId)}/movimientos`)
  return data
}

export async function crearNota(facturaId: string, input: CrearNotaInput, idempotencyKey: string): Promise<CrearNotaResult> {
  const { data } = await http.post<CrearNotaResult>(`/facturas/${encodeURIComponent(facturaId)}/notas-credito`, input, {
    headers: { 'Idempotency-Key': idempotencyKey },
  })
  return data
}

export async function anularNota(notaId: string, motivo: string): Promise<NotaCredito> {
  const { data } = await http.post<NotaCredito>(`/notas-credito/${encodeURIComponent(notaId)}/anular`, { motivo })
  return data
}
